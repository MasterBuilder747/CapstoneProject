package Main;

public class MainAppJavaSwing {
	public static void main (String[] args) {
		new GraphicsSwing();
	}
}
